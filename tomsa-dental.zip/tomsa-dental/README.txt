Tomsa‑Dental — site static
===============================

Cum îl pui online, varianta FĂRĂ programare/compilare:

1) Netlify (super ușor)
   - Intră pe https://app.netlify.com
   - New site from Git → sau „Deploy manually” → trage folderul „tomsa-dental” (cu index.html) în fereastră.
   - Primești un link public imediat (ex: https://tomsa-dental.netlify.app).

2) Vercel (la fel de ușor)
   - https://vercel.com → Add New → Project → „Deploy” → „Import” → Upload „tomsa-dental”
   - Link public (ex: https://tomsa-dental.vercel.app).

3) Hosting clasic
   - Urcă index.html pe hosting (în public_html).

Formularul funcționează în mod „static”: la trimitere arată mesajul de succes.
Dacă vrei să primești emailuri, folosește un serviciu gratuit de formulare (ex. Netlify Forms, Formspree) sau un backend propriu.
